package co.edu.ue.resourcemydevices;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class CFile {
    private Context context;
    private Activity activity;
    public static final int REQUEST_CODE = 23;
    public CFile(Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
    }

    private boolean statusPermissionExternalStorage() {
        int response = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if(response == PackageManager.PERMISSION_GRANTED) return true;
        return false;
    }

    private void requestPermissionExternalStorage(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            ActivityCompat.requestPermissions(this.activity,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQUEST_CODE);
            Toast.makeText(context, "Permiso otorgado", Toast.LENGTH_SHORT).show();
        }
    }
    private void createDir(File file){
        if(!file.exists()){
            file.mkdirs();
        }
    }
    public void saveFile(String nameFile, String info) {
        if (statusPermissionExternalStorage()) {
            File directory = chooseDirectory();
            if (directory != null) {
                saveDataToFile(directory, nameFile, info);
            } else {
                Toast.makeText(context, "No se pudo crear el directorio", Toast.LENGTH_LONG).show();
            }
        } else {
            requestPermissionExternalStorage();
        }
    }

    private File chooseDirectory() {
        File directory = null;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            directory = new File(Environment.getExternalStorageDirectory(), "ArchvoRecursos");
            createDir(directory);
            Toast.makeText(context, "En la ruta: " + directory, Toast.LENGTH_LONG).show();
        } else {
            directory = new File(context.getExternalFilesDir(Environment.DIRECTORY_DCIM), "ArchvoRecursos");
            createDir(directory);
            Toast.makeText(context, "En la ruta: " + directory, Toast.LENGTH_SHORT).show();
        }
        return directory;
    }

    private void saveDataToFile(File directory, String fileName, String data) {
        try {
            File file = new File(directory, fileName);
            FileWriter writer = new FileWriter(file);
            writer.append(data);
            writer.flush();
            writer.close();
            Toast.makeText(context, "Archivo guardado", Toast.LENGTH_LONG).show();
        } catch (Exception exception) {
            exception.printStackTrace();
            Toast.makeText(context, "" + exception, Toast.LENGTH_LONG).show();
        }
    }
}
