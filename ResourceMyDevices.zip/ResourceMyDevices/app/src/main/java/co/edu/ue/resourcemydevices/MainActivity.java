package co.edu.ue.resourcemydevices;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.BroadcastOptions;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Context context;

    private Activity activity;

    //Version Android
    private TextView versionAndroid;
    private int versionSDK;

    //Bateria
    private ProgressBar pbLevelBattery;
    private TextView tvLevelBattery;
    IntentFilter batteryFilter;

    //Conexion
    private TextView tvConexion;
    ConnectivityManager conexion;

    //Linterna
    CameraManager cameraManager;
    String cameraId;
    private Button onFlash;
    private Button offFlash;

    //File
    private EditText nameFile;

    //private CFile cFile;

    //Bluetooth
    private ImageButton btnSaveFile;
    private Button btnOnBluetooth;
    private Button btnOffBluetooth;
    private BluetoothAdapter btAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.context = getApplicationContext();
        this.activity = this;
        objInnit();
        onFlash.setOnClickListener(this::onLight);
        offFlash.setOnClickListener(this::offLight);
        batteryFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(broReciever, batteryFilter);
        btnOnBluetooth.setOnClickListener(this::turnOnBluetooth);
        btnOffBluetooth.setOnClickListener(this::turnOffBluetooth);
        btnSaveFile.setOnClickListener(this::saveFile);
    }

    //Battery
    BroadcastReceiver broReciever = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int levelBattery = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            pbLevelBattery.setProgress(levelBattery);
            tvLevelBattery.setText("Level Battery: "+levelBattery+"%");
        }
    };

    //Conexion
    private void checkConnection() {
        conexion = (ConnectivityManager) context.getSystemService(context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = conexion.getActiveNetworkInfo();
        boolean stateNet = networkInfo != null && networkInfo.isConnectedOrConnecting();
        if (stateNet) {
            tvConexion.setText("State ON");
            Log.d("CONNECTION", "Connected");
        } else {
            tvConexion.setText("State OFF");
            Log.d("CONNECTION", "Disconnected");
        }
    }


    //Version Android
    @Override
    protected void onResume() {
        super.onResume();
        String versionSO = Build.VERSION.RELEASE;
        versionSDK = Build.VERSION.SDK_INT;
        versionAndroid.setText("Version SO: "+versionSO+"/ SDK: "+versionSDK);
        checkConnection();
    }

    //Método off de flashlight
    private void offLight(View view){
        //si cameraManager o cameraId no esta vacio
        try {
            cameraManager.setTorchMode(cameraId, false);
        } catch (CameraAccessException e) {
            throw new RuntimeException("En la linterna"+e);
        }
    }

    //Flash Light
    private void onLight(View view){
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            cameraId = cameraManager.getCameraIdList()[0];
            cameraManager.setTorchMode(cameraId, true);
        } catch (CameraAccessException e) {
            throw new RuntimeException(e);
        }
    }
    public void saveFile(View view) {
        String name = nameFile.getText().toString() + ".txt";
        String batteryInfo = tvLevelBattery.getText().toString();
        saveDataToFile(name, batteryInfo);
    }

    private void saveDataToFile(String fileName, String data) {
        CFile cFile = new CFile(context, this);
        cFile.saveFile(fileName, data);
    }

    private void checkBluetooth() {
        if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_DENIED) {
            if (Build.VERSION.SDK_INT >= 31) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.BLUETOOTH_CONNECT}, 100);
            }
            return;
        }

        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (Build.VERSION.SDK_INT >= 31) {
            btAdapter = bluetoothManager.getAdapter();
        } else {
            btAdapter = BluetoothAdapter.getDefaultAdapter();
        }
    }

    private void initBluetooth() {
        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (Build.VERSION.SDK_INT >= 31) {
            btAdapter = bluetoothManager.getAdapter();
        } else {
            btAdapter = BluetoothAdapter.getDefaultAdapter();
        }
    }

    public void turnOnBluetooth(View view) {
        initBluetooth();
        enableBluetooth();
        checkConnection();
    }

    public void turnOffBluetooth(View view) {
        initBluetooth();
        disableBluetooth();
        checkConnection();
    }


    private void enableBluetooth() {
        try {
            if (btAdapter.isEnabled()) {
                Toast.makeText(this, "Bluetooth is already On", Toast.LENGTH_SHORT).show();
            } else {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                btAdapter.enable();
                Toast.makeText(this, "Bluetooth is On", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("ERROR BT", "enableBluetooth: " + e.getMessage(), e);
        }
    }

    private void disableBluetooth() {
        try {
            if (btAdapter.isEnabled()) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                btAdapter.disable();
                Toast.makeText(this, "Bluetooth is Off", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Bluetooth is already Off", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("ERROR BT", "disableBluetooth: " + e.getMessage(), e);
        }
    }

    private void objInnit(){
        this.versionAndroid = findViewById(R.id.tvVersionAndroid);
        this.tvLevelBattery = findViewById(R.id.tvLevelBattery);
        this.pbLevelBattery = findViewById(R.id.pbLevelBattery);
        this.tvConexion= findViewById(R.id.tvConexion);
        this.onFlash =  findViewById(R.id.btnOn);
        this.offFlash = findViewById(R.id.btnOff);
        this.btnSaveFile = findViewById(R.id.btnSaveFile);
        this.nameFile = findViewById(R.id.etNameFile);
        this.btnOnBluetooth = findViewById(R.id.btnOnBluetooth);
        this.btnOffBluetooth = findViewById(R.id.btnOffBluetooth);
    }
}